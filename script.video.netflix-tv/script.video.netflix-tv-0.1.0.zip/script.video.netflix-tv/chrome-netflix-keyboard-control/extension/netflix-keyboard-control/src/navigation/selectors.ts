export enum Selector {
  Slider = ".lolomoRow_title_card:not( .lolomoBigRow )"
}
